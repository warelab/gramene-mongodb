-- ---------------------------------------------------------------------------
-- Faster replacement for sections 3 and 4 of fix_compara_ids.sql.
--
-- The original UPDATEs restricted genome_db_id only inside the JOIN condition, which is not a
-- sargable predicate: MySQL 5.5 then full-scans gene_member (14.5M rows) and seq_member (17.5M)
-- probing the staging table per row, instead of touching the 69,421 rows it needs. Both tables are
-- MyISAM, so the write lock blocks every reader for the duration.
--
-- gene_member and seq_member both carry UNIQUE KEY genome_db_stable_id (genome_db_id, stable_id).
-- Adding an explicit genome_db_id predicate, one genome at a time, turns each statement into an
-- index range over that genome's rows only.
--
-- RUN THIS INSTEAD OF SECTION 3 if the staging tables already exist (they will, if the original
-- script got past its INSERT phase -- check with SHOW TABLES LIKE 'gramene_cmp%').
-- Safe to run after a partially-completed original: the join is on the OLD id, and the old and new
-- id spaces are disjoint, so already-renamed rows match nothing.
-- ---------------------------------------------------------------------------

USE ensembl_compara_plants_70_116;

-- medicago = 2282, lablab = 2308
UPDATE gene_member gm
  JOIN gramene_cmp_gene_map m
    ON m.genome_db_id = gm.genome_db_id AND m.old_id = gm.stable_id
   SET gm.stable_id = m.new_id
 WHERE gm.genome_db_id = 2282;        -- medicago, expect <= 44450

UPDATE gene_member gm
  JOIN gramene_cmp_gene_map m
    ON m.genome_db_id = gm.genome_db_id AND m.old_id = gm.stable_id
   SET gm.stable_id = m.new_id
 WHERE gm.genome_db_id = 2308;        -- lablab, expect <= 24971

UPDATE seq_member sm
  JOIN gramene_cmp_seq_map m
    ON m.genome_db_id = sm.genome_db_id AND m.old_id = sm.stable_id
   SET sm.stable_id = m.new_id
 WHERE sm.genome_db_id = 2282;        -- medicago, expect <= 44450

UPDATE seq_member sm
  JOIN gramene_cmp_seq_map m
    ON m.genome_db_id = sm.genome_db_id AND m.old_id = sm.stable_id
   SET sm.stable_id = m.new_id
 WHERE sm.genome_db_id = 2308;        -- lablab, expect <= 24971

-- --- verify -----------------------------------------------------------------
SELECT 'gene_member' AS tbl, genome_db_id, COUNT(*) AS total,
       SUM(stable_id REGEXP '^(gene|rna|mRNA)[0-9]+$') AS still_generic
  FROM gene_member WHERE genome_db_id IN (2282,2308) GROUP BY genome_db_id
UNION ALL
SELECT 'seq_member', genome_db_id, COUNT(*),
       SUM(stable_id LIKE 'cds:%' OR stable_id REGEXP '^[A-Z]{3}[0-9]+\\.[0-9]+$')
  FROM seq_member WHERE genome_db_id IN (2282,2308) GROUP BY genome_db_id;
-- still_generic must be 0 for both genomes in both tables.

DROP TABLE IF EXISTS gramene_cmp_gene_map;
DROP TABLE IF EXISTS gramene_cmp_seq_map;
